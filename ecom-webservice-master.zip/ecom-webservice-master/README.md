# Spring boot Web service app for sample API demontration.
- Use for sample jenkins job execution
- Use for automated CI / CD pipleline
- Use for Docker image creation
- Use for Dcoker pipeline creation


